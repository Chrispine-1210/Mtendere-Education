
import React, { useEffect, useState } from "react";
import axios from "axios";

const api = axios.create({
  baseURL: "/api",
  headers: {
    "Content-Type": "application/json",
  },
});

function App() {
  const [posts, setPosts] = useState([]);
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ title: "", content: "" });
  const [editId, setEditId] = useState(null);
  const [auth, setAuth] = useState({ email: "", password: "" });

  const token = localStorage.getItem("token");
  if (token) api.defaults.headers.common["Authorization"] = `Bearer ${token}`;

  const fetchPosts = async () => {
    const res = await api.get("/posts");
    setPosts(res.data);
  };

  useEffect(() => { fetchPosts(); }, []);

  const login = async () => {
    const res = await api.post("/auth/login", auth);
    localStorage.setItem("token", res.data.token);
    setUser(res.data.user);
    window.location.reload();
  };

  const createOrUpdate = async () => {
    if (editId) {
      await api.put(`/posts/${editId}`, form);
    } else {
      await api.post("/posts", form);
    }
    setForm({ title: "", content: "" });
    setEditId(null);
    fetchPosts();
  };

  const remove = async (id) => {
    await api.delete(`/posts/${id}`);
    fetchPosts();
  };

  const startEdit = (post) => {
    setForm({ title: post.title, content: post.content });
    setEditId(post.id);
  };

  if (!token) {
    return (
      <div>
        <h2>Login</h2>
        <input placeholder="Email" onChange={e => setAuth({...auth, email: e.target.value})} />
        <input placeholder="Password" type="password" onChange={e => setAuth({...auth, password: e.target.value})} />
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return (
    <div>
      <h1>Mtendere Post Manager</h1>
      <div>
        <input placeholder="Title" value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
        <textarea placeholder="Content" value={form.content} onChange={e => setForm({...form, content: e.target.value})} />
        <button onClick={createOrUpdate}>{editId ? "Update" : "Create"} Post</button>
      </div>
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <h3>{post.title}</h3>
            <p>{post.content}</p>
            {user?.is_admin && (
              <>
                <button onClick={() => startEdit(post)}>Edit</button>
                <button onClick={() => remove(post.id)}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
