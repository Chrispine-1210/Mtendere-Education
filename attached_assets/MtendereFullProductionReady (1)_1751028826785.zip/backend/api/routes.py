
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.database import db
from models.post import Post
from models.user import User

api_bp = Blueprint("api", __name__)

@api_bp.route("/posts", methods=["GET"])
def get_posts():
    posts = Post.query.all()
    return jsonify([p.serialize() for p in posts])

@api_bp.route("/posts", methods=["POST"])
@jwt_required()
def create_post():
    data = request.json
    user_id = get_jwt_identity()
    post = Post(title=data["title"], content=data["content"], user_id=user_id)
    db.session.add(post)
    db.session.commit()
    return jsonify(post.serialize()), 201

@api_bp.route("/posts/<int:post_id>", methods=["PUT"])
@jwt_required()
def update_post(post_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    post = Post.query.get_or_404(post_id)
    if not user.is_admin:
        return jsonify({"error": "Admin only"}), 403
    data = request.json
    post.title = data["title"]
    post.content = data["content"]
    db.session.commit()
    return jsonify(post.serialize())

@api_bp.route("/posts/<int:post_id>", methods=["DELETE"])
@jwt_required()
def delete_post(post_id):
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    post = Post.query.get_or_404(post_id)
    if not user.is_admin:
        return jsonify({"error": "Admin only"}), 403
    db.session.delete(post)
    db.session.commit()
    return jsonify({"message": "Deleted"})
